function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      var ActionType;

      (function (ActionType) {
        ActionType[ActionType["Wait"] = 0] = "Wait";
        ActionType[ActionType["Call"] = 1] = "Call";
        ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
        ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
        ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
        ActionType[ActionType["Cue"] = 5] = "Cue";
        ActionType[ActionType["Every"] = 6] = "Every";
      })(ActionType || (ActionType = {}));

      module.exports = ActionType;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";
      /**
       * Easing関数群。
       * 参考: http://gizma.com/easing/
       */

      var Easing;

      (function (Easing) {
        /**
         * 入力値をlinearした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function linear(t, b, c, d) {
          return c * t / d + b;
        }

        Easing.linear = linear;
        /**
         * 入力値をeaseInQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuad(t, b, c, d) {
          t /= d;
          return c * t * t + b;
        }

        Easing.easeInQuad = easeInQuad;
        /**
         * 入力値をeaseOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuad(t, b, c, d) {
          t /= d;
          return -c * t * (t - 2) + b;
        }

        Easing.easeOutQuad = easeOutQuad;
        /**
         * 入力値をeaseInOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuad(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t + b;
          --t;
          return -c / 2 * (t * (t - 2) - 1) + b;
        }

        Easing.easeInOutQuad = easeInOutQuad;
        /**
         * 入力値をeaseInQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCubic(t, b, c, d) {
          t /= d;
          return c * t * t * t + b;
        }

        Easing.easeInCubic = easeInCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
         */

        Easing.easeInQubic = easeInCubic;
        /**
         * 入力値をeaseOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCubic(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t + 1) + b;
        }

        Easing.easeOutCubic = easeOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
         */

        Easing.easeOutQubic = easeOutCubic;
        /**
         * 入力値をeaseInOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCubic(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t + 2) + b;
        }

        Easing.easeInOutCubic = easeInOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
         */

        Easing.easeInOutQubic = easeInOutCubic;
        /**
         * 入力値をeaseInQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuart(t, b, c, d) {
          t /= d;
          return c * t * t * t * t + b;
        }

        Easing.easeInQuart = easeInQuart;
        /**
         * 入力値をeaseOutQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuart(t, b, c, d) {
          t /= d;
          --t;
          return -c * (t * t * t * t - 1) + b;
        }

        Easing.easeOutQuart = easeOutQuart;
        /**
         * 入力値をeaseInQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuint(t, b, c, d) {
          t /= d;
          return c * t * t * t * t * t + b;
        }

        Easing.easeInQuint = easeInQuint;
        /**
         * 入力値をeaseOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuint(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t * t * t + 1) + b;
        }

        Easing.easeOutQuint = easeOutQuint;
        /**
         * 入力値をeaseInOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuint(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t * t * t + 2) + b;
        }

        Easing.easeInOutQuint = easeInOutQuint;
        /**
         * 入力値をeaseInSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInSine(t, b, c, d) {
          return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }

        Easing.easeInSine = easeInSine;
        /**
         * 入力値をeaseOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutSine(t, b, c, d) {
          return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }

        Easing.easeOutSine = easeOutSine;
        /**
         * 入力値をeaseInOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutSine(t, b, c, d) {
          return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }

        Easing.easeInOutSine = easeInOutSine;
        /**
         * 入力値をeaseInExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInExpo(t, b, c, d) {
          return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }

        Easing.easeInExpo = easeInExpo;
        /**
         * 入力値をeaseInOutExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutExpo(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
          --t;
          return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }

        Easing.easeInOutExpo = easeInOutExpo;
        /**
         * 入力値をeaseInCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCirc(t, b, c, d) {
          t /= d;
          return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }

        Easing.easeInCirc = easeInCirc;
        /**
         * 入力値をeaseOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCirc(t, b, c, d) {
          t /= d;
          --t;
          return c * Math.sqrt(1 - t * t) + b;
        }

        Easing.easeOutCirc = easeOutCirc;
        /**
         * 入力値をeaseInOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCirc(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
          t -= 2;
          return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }

        Easing.easeInOutCirc = easeInOutCirc;
      })(Easing || (Easing = {}));

      module.exports = Easing;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      var Tween = require("./Tween");
      /**
       * タイムライン機能を提供するクラス。
       */


      var Timeline =
      /** @class */
      function () {
        /**
         * Timelineを生成する。
         * @param scene タイムラインを実行する `Scene`
         */
        function Timeline(scene) {
          this._scene = scene;
          this._tweens = [];
          this._fps = this._scene.game.fps;
          this.paused = false;
          scene.update.add(this._handler, this);
        }
        /**
         * Timelineに紐付いたTweenを生成する。
         * @param target タイムライン処理の対象にするオブジェクト
         * @param option Tweenの生成オプション。省略された場合、 {modified: target.modified, destroyed: target.destroyed} が与えられた時と同様の処理を行う。
         */


        Timeline.prototype.create = function (target, option) {
          var t = new Tween(target, option);

          this._tweens.push(t);

          return t;
        };
        /**
         * Timelineに紐付いたTweenを削除する。
         * @param tween 削除するTween。
         */


        Timeline.prototype.remove = function (tween) {
          var index = this._tweens.indexOf(tween);

          if (index < 0) {
            return;
          }

          this._tweens.splice(index, 1);
        };
        /**
         * Timelineに紐付いた全Tweenの紐付けを解除する。
         */


        Timeline.prototype.clear = function () {
          this._tweens.length = 0;
        };
        /**
         * このTimelineを破棄する。
         */


        Timeline.prototype.destroy = function () {
          this._tweens.length = 0;

          if (!this._scene.destroyed()) {
            this._scene.update.remove(this._handler, this);
          }

          this._scene = undefined;
        };
        /**
         * このTimelineが破棄済みであるかを返す。
         */


        Timeline.prototype.destroyed = function () {
          return this._scene === undefined;
        };

        Timeline.prototype._handler = function () {
          if (this._tweens.length === 0 || this.paused) {
            return;
          }

          var tmp = [];

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween._fire(1000 / this._fps);

              tmp.push(tween);
            }
          }

          this._tweens = tmp;
        };

        return Timeline;
      }();

      module.exports = Timeline;
    }, {
      "./Tween": 4
    }],
    4: [function (require, module, exports) {
      "use strict";

      var Easing = require("./Easing");

      var ActionType = require("./ActionType");
      /**
       * オブジェクトの状態を変化させるアクションを定義するクラス。
       * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
       */


      var Tween =
      /** @class */
      function () {
        /**
         * Tweenを生成する。
         * @param target 対象となるオブジェクト
         * @param option オプション
         */
        function Tween(target, option) {
          this._target = target;
          this._stepIndex = 0;
          this._loop = !!option && !!option.loop;
          this._modifiedHandler = undefined;

          if (option && option.modified) {
            this._modifiedHandler = option.modified;
          } else if (target && target.modified) {
            this._modifiedHandler = target.modified;
          }

          this._destroyedHandler = undefined;

          if (option && option.destroyed) {
            this._destroyedHandler = option.destroyed;
          } else if (target && target.destroyed) {
            this._destroyedHandler = target.destroyed;
          }

          this._steps = [];
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;
        }
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.to = function (props, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType.TweenTo,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * 変化内容はアクション開始時を基準とした相対値で指定する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
         */


        Tween.prototype.by = function (props, duration, easing, multiply) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          if (multiply === void 0) {
            multiply = false;
          }

          var type = multiply ? ActionType.TweenByMult : ActionType.TweenBy;
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
         * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
         */


        Tween.prototype.con = function () {
          this._pararel = true;
          return this;
        };
        /**
         * オブジェクトの変化を停止するアクションを追加する。
         * @param duration 停止する時間（ミリ秒）
         */


        Tween.prototype.wait = function (duration) {
          var action = {
            duration: duration,
            type: ActionType.Wait,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 関数を即座に実行するアクションを追加する。
         * @param func 実行する関数
         */


        Tween.prototype.call = function (func) {
          var action = {
            func: func,
            type: ActionType.Call,
            duration: 0,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 一時停止するアクションを追加する。
         * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
         */


        Tween.prototype.pause = function () {
          var _this = this;

          return this.call(function () {
            _this.paused = true;
          });
        };
        /**
         * 待機時間をキーとして実行したい関数を複数指定する。
         * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
         */


        Tween.prototype.cue = function (funcs) {
          var keys = Object.keys(funcs);
          keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
          });
          var q = [];

          for (var i = 0; i < keys.length; ++i) {
            q.push({
              time: Number(keys[i]),
              func: funcs[keys[i]]
            });
          }

          var action = {
            type: ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
         * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.every = function (func, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            func: func,
            type: ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * ターゲットをフェードインさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeIn = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 1
          }, duration, easing);
        };
        /**
         * ターゲットをフェードアウトさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeOut = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 0
          }, duration, easing);
        };
        /**
         * ターゲットを指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveTo = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveBy = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットのX座標を指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveX = function (x, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x
          }, duration, easing);
        };
        /**
         * ターゲットのY座標を指定した座標に移動するアクションを追加する。
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveY = function (y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateTo = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateBy = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットを指定した倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing);
        };
        /**
         * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing, true);
        };
        /**
         * アニメーションが終了しているかどうかを返す。
         * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
         */


        Tween.prototype.isFinished = function () {
          var ret = false;

          if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
          }

          if (!ret) {
            ret = this._stepIndex !== 0 && this._stepIndex >= this._steps.length && !this._loop;
          }

          return ret;
        };
        /**
         * アニメーションを実行する。
         * @param delta 前フレームからの経過時間
         */


        Tween.prototype._fire = function (delta) {
          if (this._steps.length === 0 || this.isFinished() || this.paused) {
            return;
          }

          if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
              this._stepIndex = 0;
            } else {
              return;
            }
          }

          var actions = this._steps[this._stepIndex];
          var remained = false;

          for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];

            if (!action.initialized) {
              this._initAction(action);
            }

            if (action.finished) {
              continue;
            }

            action.elapsed += delta;

            switch (action.type) {
              case ActionType.Call:
                action.func.call(this._target);
                break;

              case ActionType.Every:
                var progress = action.easing(action.elapsed, 0, 1, action.duration);

                if (progress > 1) {
                  progress = 1;
                }

                action.func.call(this._target, action.elapsed, progress);
                break;

              case ActionType.TweenTo:
              case ActionType.TweenBy:
              case ActionType.TweenByMult:
                var keys = Object.keys(action.goal);

                for (var j = 0; j < keys.length; ++j) {
                  var key = keys[j];

                  if (action.elapsed >= action.duration) {
                    this._target[key] = action.goal[key];
                  } else {
                    this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                  }
                }

                break;

              case ActionType.Cue:
                var cueAction = action.cue[action.cueIndex];

                if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                  cueAction.func.call(this._target);
                  ++action.cueIndex;
                }

                break;
            }

            if (this._modifiedHandler) {
              this._modifiedHandler.call(this._target);
            }

            if (action.elapsed >= action.duration) {
              action.finished = true;
            } else {
              remained = true;
            }
          }

          if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
              actions[k].initialized = false;
            }

            ++this._stepIndex;
          }
        };
        /**
         * Tweenの実行状態をシリアライズして返す。
         */


        Tween.prototype.serializeState = function () {
          var tData = {
            _stepIndex: this._stepIndex,
            _steps: []
          };

          for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];

            for (var j = 0; j < this._steps[i].length; ++j) {
              tData._steps[i][j] = {
                input: this._steps[i][j].input,
                start: this._steps[i][j].start,
                goal: this._steps[i][j].goal,
                duration: this._steps[i][j].duration,
                elapsed: this._steps[i][j].elapsed,
                type: this._steps[i][j].type,
                cueIndex: this._steps[i][j].cueIndex,
                initialized: this._steps[i][j].initialized,
                finished: this._steps[i][j].finished
              };
            }
          }

          return tData;
        };
        /**
         * Tweenの実行状態を復元する。
         * @param serializedstate 復元に使う情報。
         */


        Tween.prototype.deserializeState = function (serializedState) {
          this._stepIndex = serializedState._stepIndex;

          for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
              if (!serializedState._steps[i][j] || !this._steps[i][j]) continue;
              this._steps[i][j].input = serializedState._steps[i][j].input;
              this._steps[i][j].start = serializedState._steps[i][j].start;
              this._steps[i][j].goal = serializedState._steps[i][j].goal;
              this._steps[i][j].duration = serializedState._steps[i][j].duration;
              this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
              this._steps[i][j].type = serializedState._steps[i][j].type;
              this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
              this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
              this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
          }
        };
        /**
         * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
         * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
         */


        Tween.prototype._push = function (action) {
          if (this._pararel) {
            this._lastStep.push(action);
          } else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
          }

          this._pararel = false;
        };

        Tween.prototype._initAction = function (action) {
          action.elapsed = 0;
          action.start = {};
          action.goal = {};
          action.cueIndex = 0;
          action.finished = false;
          action.initialized = true;

          if (action.type !== ActionType.TweenTo && action.type !== ActionType.TweenBy && action.type !== ActionType.TweenByMult) {
            return;
          }

          var keys = Object.keys(action.input);

          for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];

            if (this._target[key] !== undefined) {
              action.start[key] = this._target[key];

              if (action.type === ActionType.TweenTo) {
                action.goal[key] = action.input[key];
              } else if (action.type === ActionType.TweenBy) {
                action.goal[key] = action.start[key] + action.input[key];
              } else if (action.type === ActionType.TweenByMult) {
                action.goal[key] = action.start[key] * action.input[key];
              }
            }
          }
        };

        return Tween;
      }();

      module.exports = Tween;
    }, {
      "./ActionType": 1,
      "./Easing": 2
    }],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Timeline = require("./Timeline");
      exports.Tween = require("./Tween");
      exports.Easing = require("./Easing");
    }, {
      "./Easing": 2,
      "./Timeline": 3,
      "./Tween": 4
    }],
    6: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Button =
      /** @class */
      function (_super) {
        __extends(Button, _super);

        function Button(scene, s, x, y, w, h) {
          if (x === void 0) {
            x = 0;
          }

          if (y === void 0) {
            y = 0;
          }

          if (w === void 0) {
            w = 100;
          }

          if (h === void 0) {
            h = 50;
          }

          var _this = _super.call(this, {
            scene: scene,
            cssColor: "black",
            width: w,
            height: h,
            x: x,
            y: y,
            touchable: true
          }) || this;

          _this.num = 0;

          _this.chkEnable = function (ev) {
            return true;
          };

          _this.pushEvent = function () {};

          if (Button.font == null) {
            Button.font = new g.DynamicFont({
              game: g.game,
              fontFamily: g.FontFamily.Monospace,
              size: 32
            });
          }

          var base = new g.FilledRect({
            scene: scene,
            x: 2,
            y: 2,
            width: w - 4,
            height: h - 4,
            cssColor: "white"
          });

          _this.append(base);

          _this.label = new g.Label({
            scene: scene,
            font: Button.font,
            text: s[0],
            fontSize: 24,
            textColor: "black",
            widthAutoAdjust: false,
            textAlign: g.TextAlign.Center,
            width: w - 4
          });
          _this.label.y = (h - 4 - _this.label.height) / 2;

          _this.label.modified();

          base.append(_this.label);

          _this.pointDown.add(function (ev) {
            if (!_this.chkEnable(ev)) return;
            base.cssColor = "gray";
            base.modified();

            if (s.length !== 1) {
              _this.num = (_this.num + 1) % s.length;
              _this.label.text = s[_this.num];

              _this.label.invalidate();
            }
          });

          _this.pointUp.add(function (ev) {
            base.cssColor = "white";
            base.modified();

            _this.pushEvent(ev);
          });

          return _this;
        }

        return Button;
      }(g.FilledRect);

      exports.Button = Button;
    }, {}],
    7: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Button_1 = require("./Button");

      var Config =
      /** @class */
      function (_super) {
        __extends(Config, _super);

        function Config(scene, x, y) {
          if (x === void 0) {
            x = 0;
          }

          if (y === void 0) {
            y = 0;
          }

          var _this = _super.call(this, {
            scene: scene,
            cssColor: "black",
            width: 250,
            height: 250,
            x: x,
            y: y,
            touchable: true
          }) || this;

          _this.num = 0;
          _this.volumes = [0.5, 0.8];

          _this.chkEnable = function (ev) {
            return true;
          };

          var events = [_this.bgmEvent, _this.seEvent];
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.Monospace,
            size: 32
          });
          var base = new g.FilledRect({
            scene: scene,
            x: 2,
            y: 2,
            width: _this.width - 4,
            height: _this.height - 4,
            cssColor: "white"
          });

          _this.append(base);

          base.append(new g.Label({
            scene: scene,
            font: font,
            text: "設定",
            fontSize: 24,
            textColor: "black",
            widthAutoAdjust: false,
            textAlign: g.TextAlign.Center,
            width: 250
          }));
          var line = new g.FilledRect({
            scene: scene,
            x: 5,
            y: 30,
            width: 235,
            height: 2,
            cssColor: "#000000"
          });
          base.append(line);
          var strVol = ["ＢＧＭ", "効果音"];

          var _loop_1 = function _loop_1(i) {
            base.append(new g.Label({
              scene: scene,
              font: font,
              text: strVol[i],
              fontSize: 24,
              textColor: "black",
              x: 10,
              y: 50 + 50 * i
            }));
            var sprVol = new g.FrameSprite({
              scene: scene,
              src: scene.assets["volume"],
              width: 32,
              height: 32,
              x: 90,
              y: 50 + 50 * i,
              frames: [0, 1]
            });
            base.append(sprVol);
            var baseVol = new g.E({
              scene: scene,
              x: 130,
              y: 50 + 50 * i,
              width: 110,
              height: 32,
              touchable: true
            });
            base.append(baseVol);
            var lineVol = new g.FilledRect({
              scene: scene,
              x: 0,
              y: 13,
              width: 110,
              height: 6,
              cssColor: "gray"
            });
            baseVol.append(lineVol);
            var cursorVol = new g.FilledRect({
              scene: scene,
              x: 110 * this_1.volumes[i] - 7,
              y: 0,
              width: 15,
              height: 32,
              cssColor: "#000000"
            });
            baseVol.append(cursorVol);
            var flgMute = false;
            baseVol.pointMove.add(function (e) {
              var posX = e.point.x + e.startDelta.x;
              if (posX < 7) posX = 7;
              if (posX > 103) posX = 103;
              cursorVol.x = posX - 7;
              cursorVol.modified();
              flgMute = posX - 7 === 0;
            });
            baseVol.pointUp.add(function (e) {
              if (flgMute) {
                sprVol.frameNumber = 1;
              } else {
                sprVol.frameNumber = 0;
              }

              sprVol.modified();
              _this.volumes[i] = cursorVol.x / 110;

              if (i === 0 && _this.bgmEvent !== undefined) {
                _this.bgmEvent(_this.volumes[i]);
              }
            });
          };

          var this_1 = this;

          for (var i = 0; i < 2; i++) {
            _loop_1(i);
          }

          var colors = ["gray", "black", "white", "green", "navy"];
          var colorNum = 0; //背景色

          base.append(new g.Label({
            scene: scene,
            font: font,
            text: "背景色",
            fontSize: 24,
            textColor: "black",
            x: 10,
            y: 150
          }));
          base.append(new g.FilledRect({
            scene: scene,
            x: 130,
            y: 150,
            width: 110,
            height: 40,
            cssColor: "#000000"
          }));
          var sprColor = new g.FilledRect({
            scene: scene,
            x: 132,
            y: 152,
            width: 106,
            height: 36,
            cssColor: "gray",
            touchable: true
          });
          base.append(sprColor);
          sprColor.pointDown.add(function (e) {
            colorNum = (colorNum + 1) % colors.length;
            sprColor.cssColor = colors[colorNum];
            sprColor.modified();

            if (_this.colorEvent !== undefined) {
              _this.colorEvent(colors[colorNum]);
            }
          }); //ランキング表示

          var btnRank = new Button_1.Button(scene, ["ランキング"], 2, 198, 130, 45);
          base.append(btnRank);

          btnRank.pushEvent = function () {
            if (typeof window !== "undefined" && window.RPGAtsumaru) {
              window.RPGAtsumaru.experimental.scoreboards.display(1);
            }
          }; //閉じる


          var btnClose = new Button_1.Button(scene, ["閉じる"], 138, 198, 105, 45);
          base.append(btnClose);

          btnClose.pushEvent = function () {
            _this.hide();
          };

          return _this;
        }

        return Config;
      }(g.FilledRect);

      exports.Config = Config;
    }, {
      "./Button": 6
    }],
    8: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      }); //メインのゲーム画面

      var MainGame =
      /** @class */
      function (_super) {
        __extends(MainGame, _super);

        function MainGame(scene) {
          var _this = this;

          var tl = require("@akashic-extension/akashic-timeline");

          var timeline = new tl.Timeline(scene);
          _this = _super.call(this, {
            scene: scene,
            x: 0,
            y: 0,
            width: 640,
            height: 360
          }) || this;
          var bg = new g.FilledRect({
            scene: scene,
            width: 640,
            height: 360,
            cssColor: "black",
            opacity: 0.5
          });

          _this.append(bg);

          var panelSize = 80; //出す数字の設定

          var arrNum = [];

          for (var i = 2; i <= 40; i++) {
            for (var j = 2; j <= 40; j++) {
              if (i != j && (i % j === 0 || j % i === 0)) {
                arrNum.push(i);
              }
            }
          }

          console.log(arrNum);
          var base = new g.E({
            scene: scene
          });

          _this.append(base); //手札を置く場所


          var areas = [];

          var _loop_1 = function _loop_1(i) {
            var panel = new g.Sprite({
              scene: scene,
              x: 430,
              y: (panelSize + 10) * i + 70,
              src: scene.assets["map"],
              touchable: true
            });
            areas.push(panel);
            base.append(panel);
            panel.pointDown.add(function () {
              if (!scene.isStart) return;

              if (i === 0 && !panel.tag) {
                nowPanelNum = i;
                next();
                nowPanelNum = 1;
              } else {
                nowPanelNum = i;
                sprCursor.y = panel.y - 5;
                sprCursor.modified();
              }

              scene.playSound("se_move");
            });
          };

          for (var i = 0; i < 2; i++) {
            _loop_1(i);
          } //ネクストブロック


          for (var i = 0; i < 4; i++) {
            var panel = new g.Sprite({
              scene: scene,
              x: 70 * i + 430,
              y: 240,
              src: scene.assets["map"],
              scaleX: 0.8,
              scaleY: 0.8
            });
            areas.push(panel);
            base.append(panel);
          } //キープ


          var sprKeep = new g.Sprite({
            scene: scene,
            src: scene.assets["keep"],
            y: 20
          });
          areas[0].append(sprKeep); //キープと一番目の切り替え用

          var sprCursor = new g.Sprite({
            scene: scene,
            x: 430 - 5,
            y: 70 - 5 + 90,
            src: scene.assets["cursor"]
          });
          base.append(sprCursor); //エフェクト

          var effects = [];

          for (var i = 0; i < 10; i++) {
            var effect = new Effect(scene, panelSize);
            effects.push(effect);
          } //


          var dx = [0, 1, 0, -1];
          var dy = [-1, 0, 1, 0];
          var comboCnt = 0;
          var isStop = false; //移動中やコンボ中にパネルを置けないようにするフラグ

          var nowPanelNum = 1; //0:キープ 1:一番上
          //割れるかどうかチェック

          var chkDivide = function chkDivide() {
            var isDivide = false; //割る数を格納する配列作成

            var list = [];

            for (var y = 0; y < 6; y++) {
              list[y] = [];

              for (var x = 0; x < 6; x++) {
                list[y][x] = [];
              }
            } //割る数を格納


            for (var y = 1; y < maps.length - 1; y++) {
              for (var x = 1; x < maps[y].length - 1; x++) {
                if (!maps[y][x].tag) continue;
                var num2 = maps[y][x].tag.num;

                for (var i = 0; i < 4; i++) {
                  var map = maps[y + dy[i]][x + dx[i]];
                  if (!map.tag) continue;
                  var num1 = map.tag.num;

                  if (num1 % num2 === 0) {
                    list[y][x].push(num2);
                    list[y + dy[i]][x + dx[i]].push(num2);
                    maps[y][x].tag.frameNumber = 1;
                    maps[y][x].tag.modified();
                    maps[y + dy[i]][x + dx[i]].tag.frameNumber = 1;
                    maps[y + dy[i]][x + dx[i]].tag.modified();
                    isDivide = true;
                  }
                }
              }
            }

            return {
              flg: isDivide,
              list: list
            };
          }; //詰みチェックとリスタート処理


          var mate = function mate() {
            //詰みチェック
            var isMate = true;
            var arr = [];

            for (var y = 1; y < maps.length - 1; y++) {
              for (var x = 1; x < maps[y].length - 1; x++) {
                if (!maps[y][x].tag) {
                  isMate = false;
                  break;
                }

                arr.push(maps[y][x].tag);
              }

              if (!isMate) break;
            }

            if (isMate) {
              sprMate.show();
              scene.addScore(-3000);
              timeline.create().every(function (a, b) {
                var p = arr[Math.floor((arr.length - 1) * b)];

                if (p.frameNumber === 0) {
                  p.frameNumber = 2;
                  p.modified();
                }
              }, 1000);
              scene.setTimeout(function () {
                sprMate.hide();
                start();
              }, 2500);
              scene.playSound("biri");
            } else {
              isStop = false;
            }
          };

          var score = 0; //スコア加算用
          //割る処理

          var divide = function divide(list) {
            var panelCnt = 0; //割れたパネルの数カウント用
            //割る

            for (var y = 1; y < maps.length - 1; y++) {
              for (var x = 1; x < maps[y].length - 1; x++) {
                var panel = maps[y][x].tag;
                if (!panel || list[y][x].length === 0) continue;
                var num = panel.num;
                var sortList = list[y][x].filter(function (x, i, self) {
                  return self.indexOf(x) === i;
                }).sort(function (a, b) {
                  return b - a;
                });

                for (var i = 0; i < sortList.length; i++) {
                  if (num % sortList[i] !== 0) continue;
                  num = num / sortList[i];
                  if (num === 1) break;
                }

                if (num === 1) {
                  maps[y][x].tag = undefined;
                  panels.push(panel);
                }

                panel.setNum(num);
                var effect = effects.pop();
                base.append(effect);
                effect.startEffect(panel);
                effects.unshift(effect);
                panel.frameNumber = 0;
                panel.modified();
                panelCnt++;

                if (panelCnt <= 2) {
                  score += 200 * comboCnt; //score += 200 * Math.pow(comboCnt,3);
                } else {
                  score += (200 + (panelCnt - 2) * 40) * comboCnt; //score += (200 + ((panelCnt - 2) * 40)) * Math.pow(comboCnt,3);
                }
              }
            } //消したパネルの数表示


            sprNum.show();
            labelNum.text = "" + panelCnt;
            labelNum.invalidate();
            scene.setTimeout(function () {
              sprNum.hide();
            }, 800);
            scene.playSound("se_hit");
            var d = chkDivide();

            if (d.flg) {
              scene.setTimeout(function () {
                comboCnt++; //連鎖数表示

                if (comboCnt >= 2) {
                  sprCombo.show();
                  labelCombo.text = "" + comboCnt;
                  labelCombo.invalidate();
                  scene.setTimeout(function () {
                    sprCombo.hide();
                  }, 800);
                }

                divide(d.list); //再帰させて連鎖
              }, 800);
            } else {
              scene.addScore(score);
              mate();
            }
          }; //手札をずらす


          var next = function next() {
            for (var i = nowPanelNum; i < areas.length - 1; i++) {
              var p = areas[i + 1].tag;
              areas[i].tag = p;
              timeline.create(p).moveTo(areas[i].x, areas[i].y, 200).con().scaleTo(areas[i].scaleX, areas[i].scaleY, 200);
            }

            var np = panels.pop();
            var area = areas[areas.length - 1];
            np.x = area.x;
            np.y = area.y;
            np.scale(area.scaleX);
            np.setNum(arrNum[scene.random.get(0, arrNum.length - 1)]);
            np.modified();
            base.append(np);
            area.tag = np;
          }; //盤面


          var maps = [];

          for (var y = 0; y < 6; y++) {
            maps[y] = [];

            var _loop_2 = function _loop_2(x) {
              var panel = new g.Sprite({
                scene: scene,
                x: panelSize * x + 0,
                y: panelSize * y - 60,
                src: scene.assets["map"],
                touchable: true
              });
              maps[y][x] = panel;

              if (x > 0 && y > 0 && x < 5 && y < 5) {
                base.append(panel);
              } //クリックイベント


              panel.pointDown.add(function () {
                if (isStop || !scene.isStart) return;

                if (panel.tag != undefined) {
                  scene.addScore(-100);
                  var p_1 = panel.tag;
                  p_1.frameNumber = 2;
                  p_1.modified();
                  scene.playSound("se_miss");
                  return;
                }

                var p = areas[nowPanelNum].tag;
                panel.tag = p;
                isStop = true;
                timeline.create(p).moveTo(panel.x, panel.y, 180).wait(200).call(function () {
                  comboCnt = 1;
                  score = 0;
                  var d = chkDivide();

                  if (d.flg) {
                    scene.setTimeout(function () {
                      divide(d.list);
                    }, 200);
                  } else {
                    mate();
                  }
                }); //手札をずらす

                if (nowPanelNum === 0) {
                  nowPanelNum = 1;
                  sprCursor.y = areas[nowPanelNum].y - 5;
                  areas[0].tag = undefined;
                } else {
                  next();
                }

                scene.playSound("se_move");
              });
              panel.pointUp.add(function () {
                if (isStop || !scene.isStart) return;

                if (panel.tag != undefined) {
                  var p = panel.tag;
                  p.frameNumber = 0;
                  p.modified();
                  return;
                }
              });
            };

            for (var x = 0; x < 6; x++) {
              _loop_2(x);
            }
          } //枠


          var waku = new g.Sprite({
            scene: scene,
            src: scene.assets["waku"],
            x: 80 - 10,
            y: 20 - 10
          });
          base.append(waku); //設置するパネル

          var panels = [];
          var panels_bk = [];

          for (var i = 0; i < 22; i++) {
            var panel = new Panel(scene, panelSize);
            panels_bk[i] = panel;
          } //消したパネルの数


          var sprNum = new g.Sprite({
            scene: scene,
            src: scene.assets["combo"],
            width: 108,
            height: 40,
            srcY: 0,
            x: 210,
            y: 50
          });

          _this.append(sprNum);

          sprNum.hide();
          var labelNum = new g.Label({
            scene: scene,
            font: scene.numFontB,
            text: "0",
            fontSize: 40,
            x: -40
          });
          sprNum.append(labelNum); //連鎖数

          var sprCombo = new g.Sprite({
            scene: scene,
            src: scene.assets["combo"],
            width: 108,
            height: 40,
            srcY: 40,
            x: 210,
            y: 100
          });

          _this.append(sprCombo);

          sprCombo.hide();
          var labelCombo = new g.Label({
            scene: scene,
            font: scene.numFontP,
            text: "0",
            fontSize: 40,
            x: -40
          });
          sprCombo.append(labelCombo); //詰み表示

          var sprMate = new g.Sprite({
            scene: scene,
            src: scene.assets["combo"],
            width: 108,
            height: 40,
            srcY: 80,
            x: 200,
            y: 130
          });

          _this.append(sprMate);

          sprMate.hide();
          var labelMate = new g.Label({
            scene: scene,
            font: scene.numFontR,
            text: "-3000",
            fontSize: 32,
            x: -40,
            y: 50
          });
          sprMate.append(labelMate);

          _this.finish = function () {};

          var start = function start() {
            panels.length = 0;
            panels_bk.forEach(function (p) {
              if (p.parent) p.remove();
              panels.push(p);
            }); //盤面クリア

            for (var y = 1; y < maps.length - 1; y++) {
              for (var x = 1; x < maps[y].length - 1; x++) {
                maps[y][x].tag = undefined;
              }
            }

            nowPanelNum = 1; //キープクリア

            areas[0].tag = undefined; //手札の設定

            for (var i = 1; i < areas.length; i++) {
              var p = areas[i];
              var panel = panels.pop();
              panel.x = p.x;
              panel.y = p.y;
              panel.scale(p.scaleX);
              panel.setNum(arrNum[scene.random.get(0, arrNum.length - 1)]);
              panel.modified();
              base.append(panel);
              p.tag = panel;
            }

            isStop = false;
          }; //リセット


          _this.reset = function () {
            start();
          };

          return _this;
        }

        return MainGame;
      }(g.E);

      exports.MainGame = MainGame; //エフェクトクラス

      var Effect =
      /** @class */
      function (_super) {
        __extends(Effect, _super);

        function Effect(scene, panelSize) {
          var _this = _super.call(this, {
            scene: scene,
            width: panelSize,
            height: panelSize,
            angle: 15
          }) || this;

          var tl = require("@akashic-extension/akashic-timeline");

          var timeline = new tl.Timeline(scene);
          var effects = [];
          var size = panelSize / 2;

          for (var i = 0; i < 4; i++) {
            var effect = new g.FilledRect({
              scene: scene,
              x: size * (i % 2),
              y: size * Math.floor(i / 2),
              width: size,
              height: size,
              cssColor: "yellow",
              opacity: 0.8
            });
            effect.hide();
            effects.push(effect);

            _this.append(effect);
          } //エフェクト表示


          var dx = [-1, 1, -1, 1];
          var dy = [-1, -1, 1, 1];

          _this.startEffect = function (panel) {
            _this.x = panel.x;
            _this.y = panel.y;

            _this.modified();

            var _loop_3 = function _loop_3(i) {
              var effect = effects[i];
              effect.x = size * (i % 2);
              effect.y = size * Math.floor(i / 2);
              effect.show();
              timeline.create(effect).wait(100).moveBy(dx[i] * size, dy[i] * size, 300).call(function () {
                effect.hide();
              });
            };

            for (var i = 0; i < 4; i++) {
              _loop_3(i);
            }
          };

          return _this;
        }

        return Effect;
      }(g.E); //パネルクラス


      var Panel =
      /** @class */
      function (_super) {
        __extends(Panel, _super);

        function Panel(scene, panelSize) {
          var _this = _super.call(this, {
            scene: scene,
            width: panelSize,
            height: panelSize,
            frames: [0, 1, 2],
            src: scene.assets["panel"]
          }) || this;

          _this.num = 0; //数字ラベル

          var label = new g.Label({
            scene: scene,
            y: 20,
            font: scene.numFontK,
            fontSize: 38,
            textAlign: g.TextAlign.Center,
            widthAutoAdjust: false,
            width: panelSize - 2,
            text: "1"
          });

          _this.append(label); //数字セット


          _this.setNum = function (num) {
            if (num != 1) {
              _this.frameNumber = 0;
              _this.num = num;

              _this.modified();

              label.text = "" + num;
              label.invalidate();

              _this.show(); //いまいち

            } else {
              _this.hide();
            }
          };

          return _this;
        }

        return Panel;
      }(g.FrameSprite);
    }, {
      "@akashic-extension/akashic-timeline": 5
    }],
    9: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var MainGame_1 = require("./MainGame");

      var Config_1 = require("./Config");

      var Button_1 = require("./Button");
      /* tslint:disable: align */


      var MainScene =
      /** @class */
      function (_super) {
        __extends(MainScene, _super);

        function MainScene(param) {
          var _this = this;

          param.assetIds = ["img_numbers_n", "img_numbers_n_red", "title", "start", "finish", "score", "time", "panel", "map", "waku", "cursor", "combo", "keep", "config", "volume", "test", "glyph72", "number_k", "number_b", "number_y", "number_p", "se_start", "se_timeup", "bgm", "se_move", "se_miss", "se_hit", "se_miss", "biri"];
          _this = _super.call(this, param) || this;

          var tl = require("@akashic-extension/akashic-timeline");

          var timeline = new tl.Timeline(_this);
          var timeline2 = new tl.Timeline(_this);
          var isDebug = false;

          _this.loaded.add(function () {
            g.game.vars.gameState = {
              score: 0
            }; // 何も送られてこない時は、標準の乱数生成器を使う

            _this.random = g.game.random; //ミニゲームチャット用モードの取得と乱数シード設定

            var mode = "";

            if (typeof window !== "undefined") {
              var url = new URL(location.href);
              var seed = url.searchParams.get("date");
              if (seed) _this.random = new g.XorshiftRandomGenerator(parseInt(seed));
              mode = url.searchParams.get("mode");
            }

            _this.message.add(function (msg) {
              if (msg.data && msg.data.type === "start" && msg.data.parameters) {
                var sessionParameters = msg.data.parameters;

                if (sessionParameters.randomSeed != null) {
                  // プレイヤー間で共通の乱数生成器を生成
                  // `g.XorshiftRandomGenerator` は Akashic Engine の提供する乱数生成器実装で、 `g.game.random` と同じ型。
                  _this.random = new g.XorshiftRandomGenerator(sessionParameters.randomSeed);
                }
              }
            }); // 配信者のIDを取得


            _this.lastJoinedPlayerId = "";
            g.game.join.add(function (ev) {
              _this.lastJoinedPlayerId = ev.player.id;
            }); // 背景

            var bg = new g.FilledRect({
              scene: _this,
              width: 640,
              height: 360,
              cssColor: "#303030",
              opacity: 0
            });

            _this.append(bg);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug || mode == "game") {
              bg.opacity = 1.0;
              bg.modified();
            } else {
              bg.opacity = 0.8;
              bg.modified();
            }

            var base = new g.E({
              scene: _this
            });

            _this.append(base);

            base.hide();
            var uiBase = new g.E({
              scene: _this
            });

            _this.append(uiBase);

            uiBase.hide(); //タイトル

            var sprTitle = new g.Sprite({
              scene: _this,
              src: _this.assets["title"],
              x: 70
            });

            _this.append(sprTitle);

            timeline.create(sprTitle, {
              modified: sprTitle.modified,
              destroyd: sprTitle.destroyed
            }).wait(isDebug ? 1000 : 5000).moveBy(-800, 0, 200).call(function () {
              bg.show();
              base.show();
              uiBase.show();
              _this.isStart = true;
              reset();
            });
            var glyph = JSON.parse(_this.assets["test"].data);
            var numFont = new g.BitmapFont({
              src: _this.assets["img_numbers_n"],
              map: glyph.map,
              defaultGlyphWidth: glyph.width,
              defaultGlyphHeight: glyph.height,
              missingGlyph: glyph.missingGlyph
            });
            _this.numFont = numFont;
            var numFontRed = new g.BitmapFont({
              src: _this.assets["img_numbers_n_red"],
              map: glyph.map,
              defaultGlyphWidth: glyph.width,
              defaultGlyphHeight: glyph.height,
              missingGlyph: glyph.missingGlyph
            });
            _this.numFontR = numFontRed;
            glyph = JSON.parse(_this.assets["glyph72"].data);
            var numFontB = new g.BitmapFont({
              src: _this.assets["number_b"],
              map: glyph.map,
              defaultGlyphWidth: 65,
              defaultGlyphHeight: 80
            });
            _this.numFontB = numFontB;
            var numFontK = new g.BitmapFont({
              src: _this.assets["number_k"],
              map: glyph.map,
              defaultGlyphWidth: 65,
              defaultGlyphHeight: 80
            });
            _this.numFontK = numFontK;
            _this.numFontY = new g.BitmapFont({
              src: _this.assets["number_y"],
              map: glyph.map,
              defaultGlyphWidth: 72,
              defaultGlyphHeight: 80
            });
            _this.numFontP = new g.BitmapFont({
              src: _this.assets["number_p"],
              map: glyph.map,
              defaultGlyphWidth: 72,
              defaultGlyphHeight: 80
            }); //スコア

            uiBase.append(new g.Sprite({
              scene: _this,
              src: _this.assets["score"],
              x: 420,
              y: 5,
              height: 32
            }));
            var score = 0;
            var labelScore = new g.Label({
              scene: _this,
              x: 430,
              y: 40,
              width: 32 * 6,
              fontSize: 32,
              font: numFont,
              text: "0P",
              textAlign: g.TextAlign.Right,
              widthAutoAdjust: false
            });
            uiBase.append(labelScore);
            var labelScorePlus = new g.Label({
              scene: _this,
              x: 312,
              y: 80,
              width: 32 * 10,
              fontSize: 32,
              font: numFontRed,
              text: "+0",
              textAlign: g.TextAlign.Right,
              widthAutoAdjust: false
            });
            uiBase.append(labelScorePlus); //タイム

            uiBase.append(new g.Sprite({
              scene: _this,
              src: _this.assets["time"],
              x: 540,
              y: 320
            }));
            var labelTime = new g.Label({
              scene: _this,
              font: numFont,
              fontSize: 32,
              text: "70",
              x: 580,
              y: 323
            });
            uiBase.append(labelTime); //開始

            var sprStart = new g.Sprite({
              scene: _this,
              src: _this.assets["start"],
              x: 50,
              y: 100
            });
            uiBase.append(sprStart);
            sprStart.hide(); //終了

            var finishBase = new g.E({
              scene: _this,
              x: 0,
              y: 0
            });

            _this.append(finishBase);

            finishBase.hide();
            var finishBg = new g.FilledRect({
              scene: _this,
              width: 640,
              height: 360,
              cssColor: "#000000",
              opacity: 0.3
            });
            finishBase.append(finishBg);
            var sprFinish = new g.Sprite({
              scene: _this,
              src: _this.assets["finish"],
              x: 120,
              y: 100
            });
            finishBase.append(sprFinish); //最前面

            var fg = new g.FilledRect({
              scene: _this,
              width: 640,
              height: 360,
              cssColor: "#ff0000",
              opacity: 0.0
            });

            _this.append(fg); //リセットボタン


            var btnReset = new Button_1.Button(_this, ["リセット"], 500, 260, 130);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug || mode == "game") {
              finishBase.append(btnReset);

              btnReset.pushEvent = function () {
                reset();
              };
            } //ランキングボタン


            var btnRanking = new Button_1.Button(_this, ["ランキング"], 500, 200, 130);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug) {
              finishBase.append(btnRanking);

              btnRanking.pushEvent = function () {
                window.RPGAtsumaru.experimental.scoreboards.display(1);
              };
            } //設定ボタン


            var btnConfig = new g.Sprite({
              scene: _this,
              x: 600,
              y: 0,
              src: _this.assets["config"],
              touchable: true
            });

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug || mode == "game") {
              _this.append(btnConfig);
            } //設定画面


            var config = new Config_1.Config(_this, 380, 40);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug || mode == "game") {
              _this.append(config);
            }

            config.hide();
            btnConfig.pointDown.add(function () {
              if (config.state & 1) {
                config.show();
              } else {
                config.hide();
              }
            });

            config.bgmEvent = function (num) {
              bgm.changeVolume(0.5 * num);
            };

            config.colorEvent = function (str) {
              bg.cssColor = str;
              bg.modified();
            };

            var bgm = _this.assets["bgm"].play();

            bgm.changeVolume(isDebug ? 0.0 : 0.2);

            _this.playSound = function (name) {
              _this.assets[name].play().changeVolume(config.volumes[1]);
            }; //ゲームメイン


            var game = new MainGame_1.MainGame(_this);
            base.append(game); //メインループ

            var bkTime = 0;
            var timeLimit = 90;
            var startTime = 0;

            _this.update.add(function () {
              //return;//デバッグ
              if (!_this.isStart) return;
              var t = timeLimit - Math.floor((Date.now() - startTime) / 1000); //終了処理

              if (t <= -1) {
                fg.cssColor = "#000000";
                fg.opacity = 0.0;
                fg.modified();
                finishBase.show();
                _this.isStart = false;

                _this.playSound("se_timeup");

                timeline.create().wait(2500).call(function () {
                  if (typeof window !== "undefined" && window.RPGAtsumaru) {
                    window.RPGAtsumaru.experimental.scoreboards.setRecord(1, g.game.vars.gameState.score).then(function () {
                      btnRanking.show();
                      btnReset.show();
                    });
                  }

                  if (isDebug) {
                    btnRanking.show();
                    btnReset.show();
                  } //ミニゲームチャット用ランキング設定


                  if (mode == "game") {
                    window.parent.postMessage({
                      score: g.game.vars.gameState.score,
                      id: 1
                    }, '*');
                    btnReset.show();
                  }
                });
                game.finish();
                return;
              }

              labelTime.text = "" + t;
              labelTime.invalidate();

              if (bkTime !== t && t <= 5) {
                fg.opacity = 0.1;
                fg.modified();
                timeline.create().wait(500).call(function () {
                  fg.opacity = 0.0;
                  fg.modified();
                });
              }

              bkTime = t;
            }); //スコア加算表示


            var bkTweenScore;

            _this.addScore = function (num) {
              if (score + num < 0) {
                num = -score;
              }

              score += num;
              timeline.create().every(function (e, p) {
                labelScore.text = "" + (score - Math.floor(num * (1 - p))) + "P";
                labelScore.invalidate();
              }, 500);
              labelScorePlus.text = (num >= 0 ? "+" : "") + num;
              labelScorePlus.invalidate();
              if (bkTweenScore) timeline2.remove(bkTweenScore);
              bkTweenScore = timeline2.create().every(function (e, p) {
                labelScorePlus.opacity = p;
                labelScorePlus.modified();
              }, 100).wait(4000).call(function () {
                labelScorePlus.opacity = 0;
                labelScorePlus.modified();
              });
              g.game.vars.gameState.score = score;
              if (typeof window !== "undefined") window.score = score;
            }; //リセット


            var reset = function reset() {
              bkTime = 0;
              startTime = Date.now();
              _this.isStart = true;
              score = 0;
              labelScore.text = "0P";
              labelScore.invalidate();
              labelScorePlus.text = "";
              labelScorePlus.invalidate();
              sprStart.show();
              timeline.create().wait(750).call(function () {
                sprStart.hide();
              });
              btnReset.hide();
              btnRanking.hide();
              fg.opacity = 0;
              fg.modified();
              finishBase.hide();
              startTime = Date.now();
              game.reset();

              _this.playSound("se_start");
            };
          });

          return _this;
        }

        return MainScene;
      }(g.Scene);

      exports.MainScene = MainScene;
    }, {
      "./Button": 6,
      "./Config": 7,
      "./MainGame": 8,
      "@akashic-extension/akashic-timeline": 5
    }],
    10: [function (require, module, exports) {
      "use strict";

      var MainScene_1 = require("./MainScene");

      function main(param) {
        //const DEBUG_MODE: boolean = true;
        var scene = new MainScene_1.MainScene({
          game: g.game
        });
        g.game.pushScene(scene);
      }

      module.exports = main;
    }, {
      "./MainScene": 9
    }]
  }, {}, [10])(10);
});